// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	// TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
	//  even though it is a constant and the compiler buffer overflow checks are on.
	//  You need to modify this method to prevent buffer overflow without changing the account_number
	//  variable, and its position in the declaration. It must always be directly before the variable used for input.
	//  You must notify the user if they entered too much data.

	const std::string account_number = "CharlieBrown42";
	char user_input[20];
	std::cout << "Enter a value: ";

	// cin.getline allows a more secure way to retrieve user input by allowing
	// a limit to be placed on the input size. Any input that is larger than the limit
	// will simply raise an error flag in cin and will not cause a buffer overflow.
	// While the user input is larger than 19 characters (accounting for the null terminator),
	// the program will inform the user of the limit and will ask for a new value. 
	while (!std::cin.getline(user_input, sizeof(user_input))) {
		// This clears the error flag in cin allowing new input to be obtained
		std::cin.clear(); 
		// This line ensures that the user input is cleared out of cin
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); 
		std::cout << "Your input exceeded the size of the buffer. Please enter a value that is less than 20 characters." << std::endl
			<< "Enter a value: ";
	}

	std::cout << "You entered: " << user_input << std::endl;
	std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
