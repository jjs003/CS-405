// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

// Custom exception class
class SquirrelIntrustionException : public std::exception {
public:
    explicit SquirrelIntrustionException(const std::string& msg) : message(msg) {}
    const char* what() const noexcept override {
        return message.c_str();
    }
private:
    std::string message;
};

bool do_even_more_custom_application_logic()
{
    // Throw a runtime_error
    throw std::runtime_error("A runtime error has occurred!");
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    
    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // Try block to catch exceptions from do_even_more_custom_application_logic()
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        std::cout << "Exception caught during call to do_even_more_custom_application_logic: " << e.what() << std::endl;
    }

    // Throw custom exception
    throw SquirrelIntrustionException(
        "Financial Sector Catastrophe Avoided: A rogue squirrel attempted to access sensitive banking data, but was thwarted!"
    );

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // If den equals zero, throw an exception
    if (den == 0) {
        throw std::invalid_argument("Division by zero error.");
    }
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    // Try block implemented to catch exceptions
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e) {
        std::cout << "Exception caught during division: " << e.what() << std::endl;
    }
}

int main()
{
    try {
        std::cout << "Exceptions Tests!" << std::endl;
        do_division();
        do_custom_application_logic();
    }
    // Catch block for our custom exception
    catch (const SquirrelIntrustionException& e) {
        std::cout << "Squirrel intrusion detected in main: " << e.what() << std::endl;
    }
    // Catch block for standard exceptions
    catch (const std::exception& e) {
        std::cout << "Standard exception caught in main: " << e.what() << std::endl;
    }
    // Catch block for all other exceptions
    catch (...) {
        std::cout << "An unknown exception was caught in main." << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu